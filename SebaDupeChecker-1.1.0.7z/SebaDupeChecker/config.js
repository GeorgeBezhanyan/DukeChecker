import { @Vigilant, @TextProperty, @SwitchProperty, @SelectorProperty, @DecimalSliderProperty } from "../Vigilance";

@Vigilant("simonshutup", "Simon Shut Up", {
	getCategoryComparator: () => (a, b) => {
		const categories = ["AutoSS", "Extras"];
		return categories.indexOf(a.name) - categories.indexOf(b.name);
	}
})
class Settings {
	@SwitchProperty({
		name: "Toggle",
		description: "Toggle AutoSS",
		category: "AutoSS"
	})
	enabled = false;

	@TextProperty({
		name: "Delay",
		category: "AutoSS"
	})
	delay = "250";

	@DecimalSliderProperty({
		name: "Rotate Time",
		category: "AutoSS",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	rotateTime = 0.8;

	@SelectorProperty({
		name: "Rotate Algorithm",
		options: ["Linear", "Bezier"],
		category: "AutoSS"
	})
	rotateAlgorithm = 1;

	@SwitchProperty({
		name: "Allow Unknown Configuration",
		category: "AutoSS"
	})
	unknownConfiguration = false;

	@TextProperty({
		name: "Auto Start",
		category: "Extras"
	})
	autoStart = "";

	@SwitchProperty({
		name: "No Rotate",
		category: "Extras",
		description: "Minimal effort code"
	})
	noRotate = false;

	constructor() {
		this.initialize(this);
	}
}

export default new Settings();
