import Settings from "./config";
import "./features/autoss";

register("command", Settings.openGUI).setName("simonshutup").setAliases("autoss");
